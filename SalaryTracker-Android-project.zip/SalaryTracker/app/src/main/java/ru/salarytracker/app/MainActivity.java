package ru.salarytracker.app;

import android.app.Activity;
import android.os.Bundle;
import android.graphics.Color;
import android.graphics.Typeface;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.*;
import android.text.InputType;
import java.text.NumberFormat;
import java.util.Calendar;
import java.util.Locale;

public class MainActivity extends Activity {
    private final String[] months = {"Январь","Февраль","Март","Апрель","Май","Июнь","Июль","Август","Сентябрь","Октябрь","Ноябрь","Декабрь"};
    private EditText[] inputs = new EditText[12];
    private TextView totalView, averageView;
    private android.content.SharedPreferences prefs;
    private int year;

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        prefs = getSharedPreferences("salary_data", MODE_PRIVATE);
        year = Calendar.getInstance().get(Calendar.YEAR);
        buildScreen();
    }

    private int dp(float v) { return (int)(v * getResources().getDisplayMetrics().density + 0.5f); }
    private TextView text(String value, int size, boolean bold) {
        TextView t = new TextView(this);
        t.setText(value); t.setTextSize(size); t.setTextColor(Color.rgb(32, 42, 58));
        if (bold) t.setTypeface(null, Typeface.BOLD);
        return t;
    }
    private String money(double v) {
        return NumberFormat.getNumberInstance(new Locale("ru","RU")).format(Math.round(v)) + " ₽";
    }

    private void buildScreen() {
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(Color.rgb(245,247,251));
        root.setPadding(dp(18), dp(18), dp(18), dp(24));

        TextView title = text("Учёт зарплаты", 26, true);
        root.addView(title);
        TextView subtitle = text("Заполняй сумму за каждый месяц", 14, false);
        subtitle.setTextColor(Color.GRAY);
        LinearLayout.LayoutParams sp = new LinearLayout.LayoutParams(-1, -2);
        sp.bottomMargin = dp(14); root.addView(subtitle, sp);

        LinearLayout yearRow = new LinearLayout(this);
        yearRow.setGravity(Gravity.CENTER_VERTICAL);
        TextView yearLabel = text("Год: ", 17, true);
        yearRow.addView(yearLabel);
        Button prev = new Button(this); prev.setText("‹");
        Button next = new Button(this); next.setText("›");
        TextView yearText = text(String.valueOf(year), 18, true);
        yearRow.addView(prev); yearRow.addView(yearText);
        yearRow.addView(next);
        root.addView(yearRow);
        prev.setOnClickListener(v -> { year--; buildScreen(); });
        next.setOnClickListener(v -> { year++; buildScreen(); });

        LinearLayout summary = new LinearLayout(this);
        summary.setOrientation(LinearLayout.VERTICAL);
        summary.setPadding(dp(16),dp(14),dp(16),dp(14));
        summary.setBackgroundColor(Color.rgb(226,237,255));
        LinearLayout.LayoutParams sumP = new LinearLayout.LayoutParams(-1,-2);
        sumP.topMargin=dp(12); sumP.bottomMargin=dp(12);
        totalView = text("За год: 0 ₽", 20, true);
        averageView = text("В среднем за месяц: 0 ₽", 15, false);
        summary.addView(totalView); summary.addView(averageView);
        root.addView(summary,sumP);

        ScrollView scroll = new ScrollView(this);
        LinearLayout list = new LinearLayout(this); list.setOrientation(LinearLayout.VERTICAL);
        for (int i=0;i<12;i++) {
            final int index=i;
            LinearLayout row = new LinearLayout(this);
            row.setGravity(Gravity.CENTER_VERTICAL);
            row.setPadding(dp(12),dp(7),dp(12),dp(7));
            row.setBackgroundColor(Color.WHITE);
            LinearLayout.LayoutParams rp = new LinearLayout.LayoutParams(-1,-2);
            rp.bottomMargin=dp(5);
            TextView month = text(months[i],16,true);
            row.addView(month,new LinearLayout.LayoutParams(0,dp(48),1));
            EditText amount = new EditText(this);
            amount.setSingleLine(true);
            amount.setTextSize(16);
            amount.setHint("0 ₽");
            amount.setInputType(InputType.TYPE_CLASS_NUMBER | InputType.TYPE_NUMBER_FLAG_DECIMAL);
            amount.setGravity(Gravity.END | Gravity.CENTER_VERTICAL);
            amount.setEms(9);
            amount.setText(prefs.getString(key(i), ""));
            inputs[i]=amount;
            row.addView(amount,new LinearLayout.LayoutParams(dp(145),dp(48)));
            amount.addTextChangedListener(new android.text.TextWatcher() {
                public void beforeTextChanged(CharSequence s,int st,int c,int a) {}
                public void onTextChanged(CharSequence s,int st,int before,int count) { prefs.edit().putString(key(index), s.toString()).apply(); updateSummary(); }
                public void afterTextChanged(android.text.Editable e) {}
            });
            list.addView(row,rp);
        }
        scroll.addView(list);
        root.addView(scroll,new LinearLayout.LayoutParams(-1,0,1));

        Button save = new Button(this);
        save.setText("Сохранить зарплату");
        LinearLayout.LayoutParams bp = new LinearLayout.LayoutParams(-1,-2);
        bp.topMargin=dp(12);
        root.addView(save,bp);
        save.setOnClickListener(v -> {
            android.content.SharedPreferences.Editor edit=prefs.edit();
            for(int i=0;i<12;i++) edit.putString(key(i),inputs[i].getText().toString().trim());
            edit.apply();
            Toast.makeText(this,"Данные сохранены",Toast.LENGTH_SHORT).show();
            updateSummary();
        });
        setContentView(root);
        updateSummary();
    }

    private String key(int month) { return "y"+year+"_m"+month; }
    private void updateSummary() {
        if (inputs[0]==null || totalView==null) return;
        double sum=0;
        for(EditText input:inputs) if(input!=null) {
            String s=input.getText().toString().trim().replace(',', '.').replace(" ","");
            try { if(!s.isEmpty()) sum+=Double.parseDouble(s); } catch(Exception ignored) {}
        }
        totalView.setText("За год: "+money(sum));
        averageView.setText("В среднем за месяц: "+money(sum/12.0));
    }
}
